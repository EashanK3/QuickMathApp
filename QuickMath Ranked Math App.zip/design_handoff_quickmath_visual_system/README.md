# Handoff: QuickMath Visual System (Home, Practice, Results, Learn, Technique)

## Overview
A cohesive visual redesign of the 5 core QuickMath screens (`src/screens/*.tsx`), built around two signature moments: hexagonal tier badges that escalate in weight/glow by rank, and a "promotion shield" state (pip indicators + pulsing red alert) shown on Home and Practice.

## About the design files
`QuickMath.dc.html` in this folder is an **HTML/CSS design reference**, not production code. It exists to show exact layout, color, type, and the two signature interaction states. The task is to **recreate this in the existing Expo/React Native codebase** (`QuickMathApp/`), using React Native `View`/`Text`/`Pressable` + `StyleSheet`, not any HTML/DOM APIs. Reuse the existing per-screen `StyleSheet.create` pattern already in `src/screens/*.tsx` — don't introduce web-only CSS (no `clip-path`, no `box-shadow` string syntax, no `overflow-x: auto`).

## Fidelity
High-fidelity. Colors, spacing, and the two signature components (tier badge, shield strip) should be recreated precisely. Copy text and data values are illustrative sample data pulled from the real `ratings.ts` / `ladders.ts` / `techniques.ts` — don't hardcode them, wire to live `Profile` state as the existing screens already do.

## Design tokens (unchanged from `src/theme.ts`)
```
bg #0C0F14, surface #151A22, surfaceRaised #1C232E, border #242D3A
text #E8EAED, textDim #8A93A3, textFaint #5A6373
gold #E0B155, goldDim #7A6337 — tiers/promotion ONLY
accent #5B8DEF — interactive
green #4CC38A / red #E5534B — correct/incorrect
purple #A78BFA — Vedic ONLY
```
New value introduced: `#F4D18A` (light gold highlight), used only in the World Cup–tier badge gradient. No new hues added anywhere else — escalation across tiers is done by opacity/glow/fill, not new colors.

## New/changed component: TierBadge
Replaces the plain `{tier.icon} {tier.name}` text pairing in `HomeScreen.tsx` (`RatingCard`, `LockableCard`) and `ResultsScreen.tsx`.

**Shape**: hexagon. In RN, implement with a rotated-square trick or an SVG polygon (`react-native-svg`, likely already available via Expo) — CSS `clip-path` has no RN equivalent. Two nested hexagons: outer = ring/glow color, inner = fill color, icon centered on top (absolute `View` layer or SVG `<text>`/overlaid RN `Text`).

**Escalation by tier index (0–6, matches `TIERS` in `tiers.ts`)**:
| idx | Tier | Ring | Fill | Icon color | Inset | Glow |
|---|---|---|---|---|---|---|
| 0 | Novice | border `#242D3A` | surface `#151A22` | textFaint | 5px | none |
| 1 | Apprentice | goldDim | surface | textDim | 5px | none |
| 2 | Club | goldDim | surfaceRaised | gold | 4px | none |
| 3 | Expert | gold | surfaceRaised | gold | 4px | subtle (6px blur, 25% opacity) |
| 4 | Master | gold | gradient goldDim→surfaceRaised | gold | 3px | medium (10px, 35%) |
| 5 | National | gold | gradient gold→goldDim | bg (dark-on-gold) | 2px | strong (16px, 50%) |
| 6 | World Cup level | gold, animated pulse | gradient gold→`#F4D18A`→goldDim | bg, bold | 1px | animated pulse, 10–22px, 45–75% |

Badge sizes used: 26px inline on rating cards, 32–40px hero size on Results screen.

## New component: ShieldStrip
Shown whenever `profile.shields[ratingKey]` is non-null (see `rating.ts`). Replaces the current plain `shieldText` caption in `HomeScreen.tsx` and the plain caption line in `PracticeScreen.tsx`.

Layout: rounded card (10–12px radius), background `rgba(229,83,75,0.08–0.1)`, border `1px solid rgba(229,83,75,0.3–0.4)`.
- Header row: label "PROMOTION SHIELD" (uppercase, 11px, 700 weight, red) + 3 pip row, right-aligned.
- Pips: 14×6px rounded rects, 4px gap. Lit pip = solid red `#E5534B` with glow; empty pip = `rgba(229,83,75,0.15)` fill + 1px red-tinted border. Lit count = `shield.remaining`.
- Caption line below: 11–12px, red, ~85–90% opacity, e.g. "N attempts left to land a correct answer."
- **Card-level treatment** when this state is active: red-tinted border on the whole parent card + a slow pulse (2.2–2.6s) alternating a tight/loose red box-shadow. On Practice, additionally pulse the countdown-timer ring when `remaining === 1` (last-chance state) with a faster (1.4s) expanding ring pulse — this is the most tense moment in the app and should read as urgent, not just informative.

In RN: recreate the box-shadow pulse with `Animated.loop` driving `shadowOpacity`/`shadowRadius` (iOS) and `elevation` (Android has no colored shadow — consider a semi-transparent border-color animation as the Android fallback, or a scaling glow `View` behind it).

## Screens
### Home (`HomeScreen.tsx`)
- Header row unchanged (title + streak, small/plain text — deliberately not gamified).
- `RatingCard` (add/sub/mult/div): add `TierBadge` next to tier name (was plain icon+text); when `shield` is truthy, render `ShieldStrip` between the rating row and the existing `TierBar`, and apply the card-level pulse border described above.
- Vedic card: same `TierBadge` treatment but recolor ring/fill/glow to purple family (`#A78BFA` / a dim purple ~`#6D5DAE`) instead of gold — keep the hexagon shape language consistent, just recolored, so both halves of the app read as one system.
- `LockableCard` (sqrt/exp): unlocked state gets a small "UNLOCKED" pill tag (10px, gold outline, 4px radius) next to the title instead of no indicator. Locked state unchanged (existing dimmed 🔒 style is fine, just add the current-avg context line, e.g. "Unlocks at avg rating 1600 · currently 1450").

### Practice (`PracticeScreen.tsx`)
- Top row unchanged.
- Replace the current one-line shield caption with the full `ShieldStrip`, shown persistently while `shield` is active (not just the transient `promotedFlash` toast — keep that toast for the promotion instant, add the strip for the ongoing shield window).
- Timer circle: when `timeLeft <= 5`, in addition to the existing red text color, add the expanding-ring pulse animation described above.
- Feedback state (post-answer) and nudge card layout unchanged from current implementation — just confirm colors match tokens above.

### Results (`ResultsScreen.tsx`)
- Add hero `TierBadge` (32–40px, idx 5–6 style) next to the tier name line, replacing the plain icon+text.
- Everything else (stat cards, error breakdown, World Cup pace bar) matches current structure/logic — only visual polish (radius, spacing) per the reference file.

### Learn (`LearnScreen.tsx`) / Technique detail (`TechniqueScreen.tsx`)
No structural changes — current card/status-badge/step-list layout already matches the intended system. Reference file mainly documents spacing/type consistency with the other screens.

## Interactions & animation
- Progress bars: animate width transition on rating change (250–350ms ease-out) rather than snapping.
- Shield pulse: continuous loop while shield active, 2.2–2.6s period, subtle — should read as "tense," not distracting.
- World Cup badge pulse: continuous loop, 2.2–2.4s period, on Results screen whenever `tier.name === "World Cup level"`.
- Last-chance timer ring (Practice, `remaining === 1` and `timeLeft <= 5`): faster 1.4s expanding-ring pulse.

## Assets
No new image assets. Tier icons are plain glyphs already in `tiers.ts` (`• ◆ ▲ ★ ✦ ♛ 🏆`) — keep using those characters, don't source new icon assets.

## Files in this bundle
- `QuickMath.dc.html` — the HTML design reference (open in a browser to see all 5 screens side by side with real sample data).
